// JavaScript Document


jQuery(function(){
  var shrinkHeader = 30;
 
  jQuery(window).scroll(function() {
    var scroll = getCurrentScroll();
      if ( scroll >= shrinkHeader ) {
           jQuery('.navigation').addClass('shrink');
        }
        else {
            jQuery('.navigation').removeClass('shrink');
        }
  });
  jQuery(document).ready(function() {
    var scroll = getCurrentScroll();
      if ( scroll >= shrinkHeader ) {
           jQuery('.navigation').addClass('shrink');
        }
        else {
            jQuery('.navigation').removeClass('shrink');
        }
	
  });
function getCurrentScroll() {
    return window.pageYOffset || document.documentElement.scrollTop;
    }

});


jQuery('.owl-carousel').owlCarousel({
    loop:true,
    margin:25,
	autoplay:true,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
          
        },
        767:{
            items:3,
			
          
        },
        1000:{
            items:5,
            nav:true,
        }
    }
});
jQuery('.featured-carousel').owlCarousel({
    loop:true,
    margin:20,
    responsiveClass:true,
    responsive:{
        0:{
            items:2,
          
        },
        767:{
            items:3,
			
          
        },
        1000:{
            items:4,
             nav:true,
        }
    }
});
jQuery('.parts-page-logo').owlCarousel({
    loop:true,
	autoplay:true,
    margin:25,
    responsiveClass:true,
    responsive:{
        0:{
            items:2,
          
        },
        767:{
            items:4,
			
          
        },
        1000:{
            items:6,
             nav:true,
        }
    }
});

jQuery('.price-grid').owlCarousel({
    loop:false,
	autoplay:false,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
          
        },
        767:{
            items:2,
			
          
        },
        1000:{
            items:3,
            nav:true,
        }
    }
});

jQuery('.timing-belt-carosuel').owlCarousel({
    loop:true,

	autoplay:false,
    responsiveClass:true,
    responsive:{
        0:{
            items:2,
          
        },
        767:{
            items:3,
			
          
        },
        1000:{
            items:4,
            nav:true,
        }
    }
});

/*************OWL CAROUSEL********************/

   if (navigator.userAgent.match(/Trident\/7\./)) { // if IE
            $('body').on("mousewheel", function () {
                // remove default behavior
                event.preventDefault();

                //scroll without smoothing
                var wheelDelta = event.wheelDelta;
                var currentScrollPosition = window.pageYOffset;
                window.scrollTo(0, currentScrollPosition - wheelDelta);
            });
        }
		
/////////////   SlideBAr

jQuery(function(){
  jQuery('.btn.btn-default.btn-menu').click(function(){
     jQuery('.slidmenu').toggleClass('right-slide');	  
	  
	});	
	jQuery('.log-tabing li a').click(function (e) {     
   
    var href = $(this).attr('href');    

    jQuery('.log-tabing li').removeClass('active');

    jQuery('.log-tabing li a[href="'+href+'"]').closest('li').addClass('active');

         jQuery('.clutch-repair').removeClass('active');
         jQuery('.clutch-repair'+href).addClass('active');
      
	   });
	   
   

});		


		
	
//////////////////////////////

	
	
/////////////////////////////////////////////////ACCORDIAN


	